package Desplegar.formarObjeto;

import Desplegar.estructura.EstructuraDigito;
import Desplegar.estructura.SegmentarPuntos;

public class FormarDigito {

    /**
     * Creación de los objetos de la Estructura Digito  
     * @param longitud Longitud del segmento
     * @param segmentos 
     * @return Objeto EstructuraDigito
     */
    public static EstructuraDigito createSegment(int longitud, char segmentos) {

        EstructuraDigito digito = new EstructuraDigito();

        SegmentarPuntos segmentoPto0 = new SegmentarPuntos();
        SegmentarPuntos segmentoPto1 = new SegmentarPuntos();

        int orientation = -1;
        
        // Construcción de vectores
        switch (segmentos) {

            case EstructuraDigito.A:

                orientation = EstructuraDigito.HORIZONTAL;

                segmentoPto0.setI(0);
                segmentoPto1.setI(0);

                segmentoPto0.setJ(1);
                segmentoPto1.setJ(longitud);
                break;

            case EstructuraDigito.B:

                orientation = EstructuraDigito.VERTICAL;

                segmentoPto0.setJ(longitud + 1);
                segmentoPto1.setJ(longitud + 1);

                segmentoPto0.setI(1);
                segmentoPto1.setI(longitud);
                break;

            case EstructuraDigito.C:

                orientation = EstructuraDigito.VERTICAL;

                segmentoPto0.setJ(longitud + 1);
                segmentoPto1.setJ(longitud + 1);

                segmentoPto0.setI(longitud + 2);
                segmentoPto1.setI(2 * longitud + 1);
                break;

           
            case EstructuraDigito.D:

                orientation = EstructuraDigito.HORIZONTAL;

                segmentoPto0.setI(2 * (longitud + 1));
                segmentoPto1.setI(2 * (longitud + 1));

                segmentoPto0.setJ(1);
                segmentoPto1.setJ(longitud);
                break;

            
            case EstructuraDigito.E:

                orientation = EstructuraDigito.VERTICAL;

                segmentoPto0.setJ(0);
                segmentoPto1.setJ(0);

                segmentoPto0.setI(longitud + 2);
                segmentoPto1.setI(2 * longitud + 1);

                break;

            case EstructuraDigito.F:

                orientation = EstructuraDigito.VERTICAL;

                segmentoPto0.setJ(0);
                segmentoPto1.setJ(0);

                segmentoPto0.setI(1);
                segmentoPto1.setI(longitud);

                break;

            case EstructuraDigito.G:

                orientation = EstructuraDigito.HORIZONTAL;

                segmentoPto0.setI(longitud + 1);
                segmentoPto1.setI(longitud + 1);

                segmentoPto0.setJ(1);
                segmentoPto1.setJ(longitud);

                break;

            default:
                break;

        }

        digito.setOrientacion(orientation);

        digito.setPto0(segmentoPto0);
        digito.setPto1(segmentoPto1);

        return digito;

    }


}
