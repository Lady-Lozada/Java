package Desplegar.formarObjeto;

import Desplegar.estructura.DisplayDigito;
import Desplegar.estructura.Matriz;

/**
 * Crear y rellenar matriz
 */
public class ContruirLCD {

    // Número de espacios vacios entre la matriz
    private static final int ESPACIO_MEDIO = 1;

    // Construir pantalla
    private Matriz display;

    // Iterador de digitos en la pantalla
    private int imprimiendoDigitos = 0;

    /**
     * @param digitos impresión de digitos
     * @param segmentoLen longitud de la impresión
     */
    public void crearDisplay(String digitos, int segmentoLen) {

        display = new Matriz();
        crearMatrizDisplay(digitos, segmentoLen);
    }
    /**
     * @param digitos        
     * @param segmentoLen 
     */
    private void crearMatrizDisplay(String digitos, int segmentoLen) {

        int nDigitos = digitos.length();
        int matrizAlto = segmentoLen * 2 + 3;
        int matrizAncho = (segmentoLen + 2 + ESPACIO_MEDIO) * nDigitos - ESPACIO_MEDIO;

        char[][] impMatriz = new char[matrizAlto][matrizAncho];
        for (int i = 0; i < impMatriz.length; i++) {

            for (int j = 0; j < impMatriz[0].length; j++) {
                impMatriz[i][j] = ConstruirDigitoLCD.ESPACIO;
            }

        }
        display.setMatriz(impMatriz);

    }

    /**
     * Rellenar matriz
     * @param displayDigito Digito de la matriz
     */
    public void digitosLCD(DisplayDigito displayDigito) {

        char[][] verMatriz = display.getMatriz();

        int digitLen = displayDigito.getSegmentoLen();
        int columna0 = (digitLen + 2 + ESPACIO_MEDIO) * imprimiendoDigitos;

        int digitoAlto = displayDigito.getAlto();
        int digitoAncho = displayDigito.getAncho();

        for (int i = 0; i < digitoAlto; i++) {

            for (int j = columna0; j < digitoAncho + columna0; j++) {

                verMatriz[i][j] = displayDigito.getMatriz()[i][j - columna0];

            }

        }

        display.setMatriz(verMatriz);
        imprimiendoDigitos++;

    }

    public Matriz getDisplay() {
        return display;
    }
}
