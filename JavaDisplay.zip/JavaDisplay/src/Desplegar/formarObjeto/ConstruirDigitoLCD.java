package Desplegar.formarObjeto;

import Desplegar.estructura.EstructuraDigito;
import Desplegar.estructura.DisplayDigito;

public class ConstruirDigitoLCD {

    // Orientación
    private static final char HORIZONTAL = '-';
    private static final char VERTICAL = '|';

    // caracter vacio para crear la matriz vacia
    public static final char ESPACIO = ' ';

    // Construir DisplayDigito
    private DisplayDigito imprimirDigito;

    /**
     * Se inicializa matriz con espacios
     * @param digito 
     * @param segmentoLen Longitud de los segmentos del digito
     */
    public void digito(int digito, int segmentoLen) {

        imprimirDigito = new DisplayDigito(digito, segmentoLen);
        crearMatriz();

    }

    private void crearMatriz() {

        int segmentLength = imprimirDigito.getSegmentoLen();
        int matrizAlto = segmentLength * 2 + 3;
        int matrizAncho = segmentLength + 2;

        char[][] digitMatrix = new char[matrizAlto][matrizAncho];

        for (int i = 0; i < digitMatrix.length; i++) {

            for (int j = 0; j < digitMatrix[0].length; j++) {

                digitMatrix[i][j] = ESPACIO;

            }

        }

        imprimirDigito.setMatriz(digitMatrix);

    }

    /**
     * A partir del display de 7 segmentos LCD, creamos la estructura del número
     * y rellenamos la matriz
     * @param segmentoModelo 
     */
    public void constructorSegmentos(char segmentoModelo) {

        int SegmentoLen = imprimirDigito.getSegmentoLen();
        EstructuraDigito segmentNum = FormarDigito.createSegment(SegmentoLen, segmentoModelo);

        char[][] matriz = imprimirDigito.getMatriz();
        rellenarMatriz(segmentNum, matriz);

        imprimirDigito.setMatriz(matriz);

    }

    /**
     * Relleno de matriz con los segmentos
     * @param digito
     * @param matriz
     */
    private void rellenarMatriz(EstructuraDigito digito, char[][] matriz) {

        if (digito.getOrientacion() == EstructuraDigito.HORIZONTAL) {

            int row = digito.getPto0().getI();

            int columna0 = digito.getPto0().getJ();
            int columna1 = digito.getPto1().getJ();

            for (int i = columna0; i <= columna1; i++) {

                matriz[row][i] = HORIZONTAL;

            }

        } else {

            int column = digito.getPto0().getJ();

            int fila0 = digito.getPto0().getI();
            int fila1 = digito.getPto1().getI();

            for (int i = fila0; i <= fila1; i++) {

                matriz[i][column] = VERTICAL;

            }

        }

    }

    public DisplayDigito getDisplayDigit() {
        return imprimirDigito;
    }
}
