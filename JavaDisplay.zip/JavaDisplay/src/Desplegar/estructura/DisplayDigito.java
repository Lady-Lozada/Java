package Desplegar.estructura;

import java.util.HashMap;

public class DisplayDigito {

     private static HashMap<Integer, char[]> digitoSegmentoHash = new HashMap<Integer, char[]>(10);

    {
        digitoSegmentoHash.put(0, new char[]{EstructuraDigito.A, EstructuraDigito.B, EstructuraDigito.C, EstructuraDigito.D, EstructuraDigito.E, EstructuraDigito.F});
        digitoSegmentoHash.put(1, new char[]{EstructuraDigito.B, EstructuraDigito.C});
        digitoSegmentoHash.put(2, new char[]{EstructuraDigito.A, EstructuraDigito.B, EstructuraDigito.D, EstructuraDigito.E, EstructuraDigito.G});
        digitoSegmentoHash.put(3, new char[]{EstructuraDigito.A, EstructuraDigito.B, EstructuraDigito.C, EstructuraDigito.D, EstructuraDigito.G});
        digitoSegmentoHash.put(4, new char[]{EstructuraDigito.B, EstructuraDigito.C, EstructuraDigito.F, EstructuraDigito.G});
        digitoSegmentoHash.put(5, new char[]{EstructuraDigito.A, EstructuraDigito.C, EstructuraDigito.D, EstructuraDigito.F, EstructuraDigito.G});
        digitoSegmentoHash.put(6, new char[]{EstructuraDigito.A, EstructuraDigito.C, EstructuraDigito.D, EstructuraDigito.E, EstructuraDigito.F, EstructuraDigito.G});
        digitoSegmentoHash.put(7, new char[]{EstructuraDigito.A, EstructuraDigito.B, EstructuraDigito.C});
        digitoSegmentoHash.put(8, new char[]{EstructuraDigito.A, EstructuraDigito.B, EstructuraDigito.C, EstructuraDigito.D, EstructuraDigito.E, EstructuraDigito.F, EstructuraDigito.G});
        digitoSegmentoHash.put(9, new char[]{EstructuraDigito.A, EstructuraDigito.B, EstructuraDigito.C, EstructuraDigito.F, EstructuraDigito.G});
    }

    // Longitud del segmento
    private int segmentoLen;

    // Alto de size = segmentoLen * 2 + 3
    private int alto;

    //Ancho de la size = segmentoLen + 2
    private int ancho;

    // Vectores correspondientes
    private char[] segmentoVector;

    //Representacion Matriz de digitos
    private char[][] matriz;

    /**
     * @param digito   
     * @param segmentoLen 
     */
    public DisplayDigito(int digito, int segmentoLen) {
        this.segmentoLen = segmentoLen;
        alto = 2 * segmentoLen + 3;
        ancho = segmentoLen + 2;
        segmentoVector = digitoSegmentoHash.get(digito);
    }

    public static HashMap<Integer, char[]> getDigitoSegmentoHash() {
        return digitoSegmentoHash;
    }

    public static void setDigitoSegmentoHash(HashMap<Integer, char[]> digitoSegmentoHash) {
        DisplayDigito.digitoSegmentoHash = digitoSegmentoHash;
    }

    public int getSegmentoLen() {
        return segmentoLen;
    }

    public void setSegmentoLen(int segmentoLen) {
        this.segmentoLen = segmentoLen;
    }

    public int getAlto() {
        return alto;
    }

    public void setAlto(int alto) {
        this.alto = alto;
    }

    public int getAncho() {
        return ancho;
    }

    public void setAncho(int ancho) {
        this.ancho = ancho;
    }

    public char[] getSegmentoVector() {
        return segmentoVector;
    }

    public void setSegmentoVector(char[] segmentoVector) {
        this.segmentoVector = segmentoVector;
    }

    public char[][] getMatriz() {
        return matriz;
    }

    public void setMatriz(char[][] matriz) {
        this.matriz = matriz;
    }


}
