package Desplegar.estructura;

/**
 * Esta clase representa un par de coordenadas dentro de una matriz indexada 0, donde i indica fila y j indica columna
 */
public class SegmentarPuntos {

    //Fila dentro de la matriz
    private int i;
    //Columna dentro de la matriz
    private int j;

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }

    public int getJ() {
        return j;
    }

    public void setJ(int j) {
        this.j = j;
    }
}