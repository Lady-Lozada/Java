package Desplegar.estructura;

public class Matriz {

    private char[][] Matriz;

    public char[][] getMatriz() {
        return Matriz;
    }

    public void setMatriz(char[][] Matriz) {
        this.Matriz = Matriz;
    }
}
