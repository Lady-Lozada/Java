package Desplegar.estructura;

/**
 * Esta clase modela el display de 7 segmentos. Con un vector y recibe los respectivos tamaños
 *    A
 *    -
 *  F| |B
 *    G
 *    -
 *  E| |C
 *    -
 *    D
 */
public class EstructuraDigito {

    //Representacin de los tipos
    public static final char A = 'A';
    public static final char B = 'B';
    public static final char C = 'C';
    public static final char D = 'D';
    public static final char E = 'E';
    public static final char F = 'F';
    public static final char G = 'G';

    public static final int HORIZONTAL = 0;
    public static final int VERTICAL = 1;

    private SegmentarPuntos pto1;
    private SegmentarPuntos pto0;
    private int orientacion;

    public SegmentarPuntos getPto1() {
        return pto1;
    }

    public void setPto1(SegmentarPuntos pto1) {
        this.pto1 = pto1;
    }

    public SegmentarPuntos getPto0() {
        return pto0;
    }

    public void setPto0(SegmentarPuntos pto0) {
        this.pto0 = pto0;
    }

    public int getOrientacion() {
        return orientacion;
    }

    public void setOrientacion(int orientacion) {
        this.orientacion = orientacion;
    }
   
}
