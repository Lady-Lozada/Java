package Desplegar;

import Desplegar.formarObjeto.ConstruirDigitoLCD;
import Desplegar.formarObjeto.ContruirLCD;
import Desplegar.estructura.Matriz;

import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Principal {

    public static void main(String[] args) throws IOException {
           
        ejercicioTexto();
        String entrada;
        Scanner scan = new Scanner(System.in);        
        System.out.print("\n");
    
        while (true) {
         
            System.out.print("Ingrese un numero #,###... \n");
            entrada = scan.nextLine();
                        
            if (entrada.equals("0,0")) {
                break;
            
             } else if (validacion1(entrada)) { 

                Matriz display = crearDisplay(entrada);
                imprimir(display);

            } else {
                continue;
            }

            
            System.out.print("\n");
        }
        scan.close();
        System.out.print("Fin del programa. \n");
    }

    private static void ejercicioTexto() throws IOException {
        String ejercicioTxt;       
        ejercicioTxt = "Display LCD \n" + 
        "Objetivo: Crear un programa que imprime números en estilo de una pantalla LCD \n" +
        "Entrada: La entrada contiene varias líneas. Cada línea contiene 2 números separados por coma. El primer \n" +
        "número representa el tamaño de la impresión (entre 1 y 10 – esta variable se llama “size”). El segundo número \n" +
        "es el número a mostrar en la pantalla. Para terminar, se debe digitar 0,0. Esto terminará la aplicación. \n" +
        "Salida: Imprimir los números especificados usando el carácter “-“ para los caracteres horizontales, y “|” para \n" +
        "los verticales. Cada dígito debe ocupar exactamente size+2 columnas y 2*size + 3 filas. \n" +
        "Entre cada impresión debe haber una línea blanca.";
        System.out.println(ejercicioTxt);
    }

    public static Matriz crearDisplay(String line) {

        StringTokenizer stringTokenizer = new StringTokenizer(line, ",");

        String s_segmentLength = stringTokenizer.nextToken();
        int segmentLength = Integer.parseInt(s_segmentLength);

        String number = stringTokenizer.nextToken();

        ContruirLCD construirDisplayLCD = new ContruirLCD();
        construirDisplayLCD.crearDisplay(number, segmentLength);

        for (char digit : number.toCharArray()) {

            ConstruirDigitoLCD displayDigitBuilder = new ConstruirDigitoLCD();
            displayDigitBuilder.digito(Character.getNumericValue(digit), segmentLength);

            for (char segment : displayDigitBuilder.getDisplayDigit().getSegmentoVector()) {

                displayDigitBuilder.constructorSegmentos(segment);

            }

            construirDisplayLCD.digitosLCD(displayDigitBuilder.getDisplayDigit());

        }

        return construirDisplayLCD.getDisplay();

    }

    private static boolean validacion1(String entrada) throws IOException {

        if ((entrada == null) || (entrada.trim().isEmpty())) {
            System.out.println("Debe ingresar un texto con el siguiente formato: #,###...\n");
            return false;
        }
        
        int numero = 0;
        try {
            numero = tamanio(entrada);
        } catch (NumberFormatException e) {
            System.out.println("El valor ingresado antes de la coma(,) debe ser un entero entre 0 y 9.\n");
            return false;
        } catch (Exception e){
            System.out.println("El valor "+entrada+", ingresado no tiene el formato #,###...");
        }
        
        int numero2 = 0;
        try {
            numero2 = Integer.parseInt(numeroCadena(entrada));
        } catch (NumberFormatException e) {
            System.out.println("El valor ingresado antes de la coma(,) debe ser un número entre 1 y 9.\n");
                    
            return false;
        }  
        
        if ( !entrada.substring(1,2).equals(",") ) {
            System.out.println("entrada.substring(1,2): " + entrada.substring(1,2));
            System.out.println("El texto ingresado debe contener coma(,) en la segunda posición con el siguiente formato: #,###...\n");
            return false;
        }        
        
        
        if ( !(numero >= 1 || numero <= 10) ) {            
                System.out.println("El tamaño ingresado debe estar entre 1 y 10.\n");            
            return false;
        }
        return true;
    }

    private static void imprimir(Matriz display) throws IOException {
        
        char[][] lcdMatrix = display.getMatriz();

        for (int i = 0; i < lcdMatrix.length; i++) {

            StringBuilder stringBuilder = new StringBuilder();

            for (int j = 0; j < lcdMatrix[0].length; j++) {

                stringBuilder.append(lcdMatrix[i][j]);

            }

            System.out.print(stringBuilder.toString() + "\n");
        }
    }
    
    public static int tamanio(String entrada){
        int size;
        size =  Integer.parseInt(entrada.substring(0,1));
        return size; //2  -  3
    }
    
    public static String numeroCadena(String entrada){//2,12345
         String num = null;
         try {
            num = entrada.substring(2);
            
        } catch (Exception e) {
            System.out.println("El valor "+entrada+", ingresado no tiene el formato #,###...");
        }
          return num;//12345  -  67890
    }
    
}
