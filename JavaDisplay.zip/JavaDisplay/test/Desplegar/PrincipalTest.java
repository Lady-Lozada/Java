
package Desplegar;

import org.junit.Test;
import static org.junit.Assert.*;


public class PrincipalTest {
   
    /**
     * Prueba para el metodo tamanio, de la clase principal
     */
    @Test
    public void testTamanio() {
        System.out.println("Validar el tamanio de la cadena ingresada");
        String entrada = "2,1234";
        int expResult = 2;
        int result = Principal.tamanio(entrada);
        
        assertEquals(expResult, result);
        } 
        
    @Test
    public void testNumeroCadena() {
        System.out.println("numeroCadena");
        String entrada = "2,1234";
        String expResult = "1234";
        String result = Principal.numeroCadena(entrada);
        
        assertEquals(expResult, result);
        }     
    
}
